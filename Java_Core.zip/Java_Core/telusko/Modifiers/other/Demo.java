package telusko.Modifiers.other;

public class Demo {

class C extends A {

    public void abc () {
// here i ought be demonstrated that the markss can be accessed outside the packege if it is in the subclass but not outside the package
        System.out.println(markss);

    }
}

    public static void main(String[] args) {
    
        A obj = new A();
        System.out.print(obj.mark);

      
    }    
}
