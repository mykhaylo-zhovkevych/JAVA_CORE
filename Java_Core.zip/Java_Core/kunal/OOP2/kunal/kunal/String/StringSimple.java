package String;

public class StringSimple {
    public static void main (String[] args){
        int[] arr = {132,23,3,12,4};
        int a = 10;
        String mane = "My name";
    }

}
