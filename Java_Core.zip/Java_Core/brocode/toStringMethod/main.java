package brocode.toStringMethod;

public class main {

    public static void main(String[] args) {
        
        car Car = new car();

     System.out.println(Car.toString());
        // tostring() = special method that all objects inherit,
        //that returns a string that "textually represents" an object.
        //can be used both implicitly and explicitly

      /*   System.out.println(Car.make);
        System.out.println(Car.model);
        System.out.println(Car.color);
        System.out.println(Car.year);
*/
    }
}
