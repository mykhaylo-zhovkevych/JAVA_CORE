package brocode.objactPassing;

public class car {

  

    public String localname;

    car(String name ){
        localname = name;


    }

}
