package chapters.ch_01;

public class aufgabe02 {
    public static void main(String[] args) {

        double radius = 5.5;
        double perimeter = 2 * radius * Math.PI;
        double area = radius * radius * Math.PI;

        System.out.println("Area of a circle with radius 5.5 is: " + area);
        System.out.println("Perimeter of a circle with radius 5.5 is: " + perimeter);

    }
}
