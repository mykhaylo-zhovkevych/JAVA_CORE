package brocode.methodOverriding;

public @interface override {

}
