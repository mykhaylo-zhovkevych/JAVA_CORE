package brocode.abstraction;

public abstract class vehicle {

    abstract void go(); // here is no need for the body {}

}
