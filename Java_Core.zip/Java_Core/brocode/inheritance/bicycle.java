package brocode.inheritance;

public class bicycle extends vehicle
{
int wheels = 2;
int padals =2;










}
