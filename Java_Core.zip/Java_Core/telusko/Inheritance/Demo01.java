package telusko.Inheritance;

public class Demo01 extends Calc
// the Demo01 get all features form the Calc
{
    
    public int multi(int n1, int n2) {

        return n1 * n2;
    }

    public int dev(int n1, int n2) {

        return n1 /  n2;
    }
}
