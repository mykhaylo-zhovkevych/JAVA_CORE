public class aufgabe07 {
    /**
 * 2.23 (Cost of driving) Write a program that prompts the user to enter the
 * distance to drive, the fuel efficiency of the car in kilometers per liter, and
 * the price per liter, and displays the cost of the trip.
 */
public static void main(String[] args) { 
    
        double distance;
        double kilometersPerLiter;
        double pricePerLiter;


 }
}
