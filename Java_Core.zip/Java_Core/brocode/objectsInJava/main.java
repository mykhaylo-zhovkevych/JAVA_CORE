package brocode.objectsInJava;

public class main {
    public static void main(String[] args) {
    
    car myCar = new car();

   // System.out.println(myCar.madel);
   // System.out.println(myCar.make);

    myCar.drive();
        }
}
