package brocode.methodOverriding;

@override
public class dog extends animal {
// this speak mwthod is considered overriding method and that animal class is considired overwritten method
    void speak() {
        System.out.println("the dog speaks");
        }
}
