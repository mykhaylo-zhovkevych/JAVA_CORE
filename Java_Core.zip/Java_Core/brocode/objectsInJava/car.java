package brocode.objectsInJava;

public class car {
    String make = "BMW";
    String madel = "X7";
    int year = 2020;
    String color = "blue";
    double price = 50000.00;



    void drive(){
        System.out.println("youa are drivingthe car");
    }
    void brake() {
        System.out.println("you are stepping onm the bracke");
    }


}
// in this car class will be defiend the atributes and methods of a car
