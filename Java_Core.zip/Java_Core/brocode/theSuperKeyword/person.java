package brocode.theSuperKeyword;

public class person {

String name;
int age;

person(String N, int i){
this.name = N;
this.age = i;
}
public String toString(){
return this.name + "\n" + this.age + "\n";

}


}
