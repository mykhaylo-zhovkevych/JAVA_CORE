package brocode.methodOverriding;

public class animal {

void speak() {

    System.out.println("the animal speak");


    }

}
