package brocode.accessModifiers.one;

import brocode.accessModifiers.two.Asub;
import brocode.accessModifiers.two.C;


public class A {
    protected String protectedMessage = "this is protected";
    public static void main(String[] args) {
       B b =  new B();
    
        System.out.println();
    }
}

