package brocode.accessModifiers.one;


public class B {
    private String privateMessage = "this is private";
}
