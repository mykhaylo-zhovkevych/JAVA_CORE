package brocode.toStringMethod;

public class car {

    String make = "Ford";
    String model = "Mustang";
    String color = "red";
    int year = 2021;

public String toString() {

return make + model + color + year;


}

}
