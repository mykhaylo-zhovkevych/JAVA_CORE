package brocode.staticModifier;

public class main {
    public static void main(String[] args) {
        

        Friend friend1 = new Friend("Spongbob");
        Friend friend2 = new Friend("Patrik");

        

        Friend.displayFriends();
    }
}
