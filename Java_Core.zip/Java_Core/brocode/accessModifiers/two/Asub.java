package brocode.accessModifiers.two;

import brocode.accessModifiers.one.A;

public class Asub extends A{

    public static void main(String[] args) {
      Asub ASUB = new Asub();
    
        System.out.println(ASUB.protectedMessage);
    }


}
