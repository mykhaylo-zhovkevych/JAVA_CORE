package telusko.Strings;

public class AboutString {

 public static void main(String[] args) {
    
    String name = new String("navin"); // string object // in this new String in the constructor the name can be passed

    String nametwo = "pali"; // it will create the object as above me 

   System.out.println(nametwo);
   System.out.println(name.hashCode());
   System.out.println(name.charAt(1));



   }   
}
