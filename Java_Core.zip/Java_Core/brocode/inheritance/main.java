package brocode.inheritance;

public class main {
public static void main(String[] args) {

car Car = new car();
bicycle bike = new bicycle();


Car.go();

// this atributtes is unique foreach class like: padals and doors
System.out.println(Car.doors);
System.out.println(bike.padals);


    }
}
