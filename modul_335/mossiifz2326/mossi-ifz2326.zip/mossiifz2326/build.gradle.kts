plugins {
    alias(libs.plugins.android.application) version "8.1.2" apply false
}
