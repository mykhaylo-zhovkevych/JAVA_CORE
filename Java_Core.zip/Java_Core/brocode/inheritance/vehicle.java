package brocode.inheritance;

public class vehicle {

double speed;

void go()
{
    System.out.println("this vehicle is moving");
}

void stop()
{
    System.out.println("this vehicle is stopped");
}

}

// now the car class and bicycle class is subclasses of the vehicle class. the atributtes and it is methods will be give to the child classes.