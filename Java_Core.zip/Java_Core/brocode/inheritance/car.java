package brocode.inheritance;

public class car extends vehicle
{
int wheels = 4;
int doors = 4;


}
