package chapters.ch_01;


public class aufgabe01 {
    
    public static void main(String[] args) {
        int count = 0;

        while (count < 5) {
            System.out.print("Welcome to Java\n");
            count++;

        }
    }

}
