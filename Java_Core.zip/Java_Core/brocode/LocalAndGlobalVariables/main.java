package brocode.LocalAndGlobalVariables;

public class main {
    public static void main(String[] args) {
        

    // local = declared inside a method, visible to all parts of a class 
    // global = declared outside a method, but within a class visibleto all parts of a class.

diveroller DiceRoller = new diveroller();
}
}
